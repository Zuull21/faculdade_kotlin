fun main() {
/*
listOf()
Cria uma lista IMUTÁVEL (ou somente leitura)
nenhum elemento pode entrar ou sair dela!
*/
  val herois =
      listOf("Batman", "Mulher Maravilha", "Thor")

  println(herois)

  println("Primeiro: ${herois[0]}")
  println("Terceiro: ${herois[2]}")
  println("Último: ${herois[herois.size-1]}")

    println("Primeiro: ${herois.first()}")
    println("Último: ${herois.last()}")

  //  herois.add("Saitama")

/*
mutableListOf()
Cria uma lista MUTÁVEL
ou seja, podemos incluir ou retirar elementos
*/
    val paises = mutableListOf("Brasil", "México", "Chile")
    paises.add("Colômbia") // insere um elemento
    println(paises)

    paises.remove("México") // remove pelo VALOR
    paises.removeAt(0) // remove pela posição (indíce)
    println(paises)

    // incluindo mais de um elemento por vez
    paises.addAll(listOf("Cuba", "Panamá", "Panamá"))
    println(paises)
    // as listas PERMITEM elementos repetidos

    // caso existam repetições,
    // apenas o primeiro é excluído
    paises.remove("Panamá")
    println(paises)

    // inserindo em determinada posição
    paises.add(2, "Brasil")
    println(paises)

    // alterando o valor em uma determinada posição
    paises.set(3, "EUA")
    // paises[3] = "EUA"
    println(paises)

  // isEmpty() -> true se NÃO houver nada na lista
  // isNotEmpty() -> true se a lista tiver pelo menos 1 elemento
    println("Os países estão vazios? ${paises.isEmpty()}")
    println("Há países? ${paises.isNotEmpty()}")

  /*
  sort() -> ordena a lista
  usando uma ordem "natural" (alfabética, numérica, data etc)
   */

    paises.sort()
    println(paises)

    val numeros = mutableListOf(22, 80, 9, 1, 20, -12)
    numeros.sort()
    println(numeros)

 /*
 reverse() -> Ele INVERTE a lista
 O primeiro vira o último
 O antepenúltimo vira o segundo
 ....
 * */
    numeros.reverse()
    println(numeros)

// sortDescending() -> orderna "ao contrário" do que o sort()
    val bla = mutableListOf(2,8,1,9)
    bla.sortDescending()
    println(bla)

  /*
sorted() -> Cria e devolve uma CÓPIA
da lista original ordenada
Mas NÃO altera em nada a lista original
   */
    val bichos = listOf("gato", "rato", "cachorro")
    println(bichos.sorted())
    val bichosOrdenados = bichos.sorted()
    println(bichos)
    println(bichosOrdenados)

  /*
forEach {} - Abre um bloco de código que será
executado para cada elemento da lista
Por padrão, cada elemento da lista recebe o nome
de "it"
 */
    paises.forEach {
      println("Já fui no país $it")
    }

/*
Caso desejado, pode-se dar um nome explícito
para dada elemento da lista na iteração
No código abaixo o nome dado é "pais"
 */
    paises.forEach { pais ->
      println("Já fui no país $pais")
    }
  /*
  forEachIndexed { indice, valor ->
Semelhante ao forEach{}
A diferença é que é OBRIGATÓRIO termos o nome da
variável de valor.
A 1a variável é o indice (de 0 até tamanho-1)
A 2a variável é o valor de cada elemento da iteração
   */
    paises.forEachIndexed { indice, pais ->
      println("O país na posição $indice é $pais")
    }

    val paisesFiltrados =
              paises.filter { it.contains("m") }

    println(paisesFiltrados)
    println(paises)

    /*
Criem uma lista que contenha todos os países
com menos de 6 letras no nome.
#FicaDica:
   .length -> retorna o núm de letras de um texto
     */
  val paisesBla = paises.filter { it.length < 6 }
  println(paisesBla)
}

fun extras() {
  /*
subList() -> devolve uma parte da lista
o 1o argumento é o indice inicial
o 2o argumento é o indice final (excluivo)
 */
  val xyz = listOf(1,2,3,4,5,6,7,8,9)
  val parte1 = xyz.subList(0,3) // do 0 a 2 (pois é 3 exclusivo)
  val parte2 = xyz.subList(3,6) // do 3 a 5 (pois é 5 exclusivo)
  val parte3 = xyz.subList(6,9) // do 6 a 8 (pois é 9 exclusivo)
  println(parte1)
  println(parte2)
  println(parte3)

}

