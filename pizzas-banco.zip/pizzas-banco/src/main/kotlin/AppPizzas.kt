import javax.swing.JOptionPane

fun main() {

    // criamos um objeto do tipo Conexao e invocamos
    // seu método criarTabelas()
    Conexao.criarTabelas()

    val repositorio = PizzaRepositorio()
    repositorio.iniciar()

    while (true) { // loop, a princípio, infinito
       val cadastrar = JOptionPane.showInputDialog(
       "Quer cadastrar uma nova pizza? S para sim ou qualquer coisa para não")

        if (cadastrar.uppercase() != "S") {
           break // sai do while
        }

        val novaPizza = Pizza()
        novaPizza.sabor = JOptionPane.showInputDialog("Qual Sabor?")
        novaPizza.preco = JOptionPane.showInputDialog("Qual Preço?").toDouble()
        novaPizza.quantidade = JOptionPane.showInputDialog("Qual Quantidade?").toInt()

        repositorio.cadastrar(novaPizza)
    }

    var ultimo = repositorio.getUltimoCodigo()
    var codigo = JOptionPane.showInputDialog(
        "Qual pizza quer vender? Digite de 1 a $ultimo").toInt()

    if (codigo >= 1 && codigo <= ultimo) {
        val vendeu = repositorio.vender(codigo)
        val pizza = repositorio.recuperar(codigo)
        if (vendeu) {
            JOptionPane.showMessageDialog(null,
"Qtd da pizza de ${pizza.sabor} atualizada p/ ${pizza.quantidade}")
        } else {
            JOptionPane.showMessageDialog(null,
            "A pizza de ${pizza.sabor} está zerada no estoque")
        }
    }

    ultimo = repositorio.getUltimoCodigo()
    codigo = JOptionPane.showInputDialog(
    "Qual pizza quer mudar de preço? Digite de 1 a $ultimo").toInt()
    val novoPreco = JOptionPane.showInputDialog(
                    "Qual o novo preço?").toDouble()

    val atualizou = repositorio.atualizarPreco(codigo, novoPreco)
    val pizzaComNovoPreco = repositorio.recuperar(codigo)

    val mensagem = if (atualizou)
    "Pço da pizza ${pizzaComNovoPreco.sabor} att p/ R$${novoPreco}"
                   else "Pizza não encontrada"

    JOptionPane.showMessageDialog(null, mensagem)

}


