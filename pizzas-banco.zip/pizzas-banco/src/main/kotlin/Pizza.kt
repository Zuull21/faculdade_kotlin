class Pizza {
    var codigo:Int = 0
    var sabor:String = ""
    var preco:Double = 0.0
    var quantidade:Int = 0
}